iFlip Tracker — setup guide

FILES
- index.html: the app
- manifest.json: Home Screen app settings
- sw.js: basic offline cache support

IMPORTANT
This is a static web app. It is not yet published to a public URL. To install it as a Home Screen web app, host these files over HTTPS.

EASIEST HOSTING OPTION: GitHub Pages
1. Create/sign in to a GitHub account.
2. Create a new public repository named iflip-tracker.
3. Upload index.html, manifest.json, and sw.js to the repository's root.
4. Open repository Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch, select main and /(root), then Save.
6. Wait for GitHub Pages to publish. It will show your website URL.
7. Open that URL in Safari on your iPhone.
8. Tap Share > Add to Home Screen > Add.

PRIVACY / BACKUPS
- Flip history is stored locally in the browser on the device.
- Export CSV for spreadsheets or Download backup (JSON) from the History tab.
- Clearing Safari website data or changing browsers can remove locally stored history.
- Do not store full IMEI, passwords, customer personal details, or other sensitive information in notes.

PART PRICES
MobileSentrix prices are entered manually. This app does not connect to MobileSentrix or retrieve live prices.
